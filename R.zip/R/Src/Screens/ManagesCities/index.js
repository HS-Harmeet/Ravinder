import React from 'react';
import {
    AppRegistry,
    StyleSheet,
    Text,
    View,
    StatusBar,
    FlatList,
    TouchableOpacity,
    TextInput,
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Header from "../../Component/Header";
import FeatherIcon from 'react-native-vector-icons/Feather';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { AppColors } from "../../Theme";
import styles from "./style";

const ManageCities = (props) => {

    const Data = [
        {
            id:"1",
            city: "Chandigarh",
            icon: "sun",
            weather: "Clear",
            tempr: "38° / 27°"
        },
        {
            id:"2",
            city: "Mohali",
            icon: "sun",
            weather: "Clear",
            tempr: "38° / 27°",
            minus:"minus-circle-outline"
        }
    ]

    const renderList = (item) => {
        return (
            <View style={{height:150, marginTop: 15, marginHorizontal: 15, borderRadius: 10, backgroundColor: AppColors.backGround1,}}>
                <View style={{ flex: 0.5, justifyContent: 'space-between', alignItems: "center", flexDirection: "row" }}>
                    <Text style={{ fontSize: 20, textAlign: "left", marginLeft: 15, fontWeight: 'bold', color: AppColors.white }}>{item.city}</Text>
                    <Icon
                        name={item.minus}
                        color={AppColors.red}
                        size={25}
                        style={{ marginRight: 15 }}
                    />
                </View>

                <View style={{ flex: 0.5, justifyContent: "center", flexDirection: 'row' }}>
                    <View style={{ flex: 0.6, flexDirection: "row", alignItems: 'center' }}>
                        <FeatherIcon
                            name={item.icon}
                            color={AppColors.white}
                            size={25}
                            style={{
                                marginLeft: 15,
                                alignSelf: "center"
                            }}
                        />
                        <Text style={{ fontSize: 20, textAlign: "left", marginLeft: 15, color: AppColors.white }}>{item.weather}</Text>
                    </View>
                    <View style={{ flex: 0.4, justifyContent: 'center' }}>
                        <Text style={{ fontSize: 20, textAlign: "right", marginRight: 15, color: AppColors.white }}>{item.tempr}</Text>
                    </View>
                </View>
            </View>
        )
    }

    return (
        <>
            <StatusBar barStyle="dark-content" hidden={false} backgroundColor="#043B5D" translucent={true} />
            <LinearGradient
                colors={[AppColors.backGround1, AppColors.backGround2]}
                style={styles.linearGradient}
                start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
            >
                <View style={styles.container}>
                    <View style={{ flex: 0.08, marginTop: 30, flexDirection: "row" }}>
                        <TouchableOpacity
                        onPress = {() => props.navigation.goBack()}
                        style={{ flex: 0.15 }}>
                            <Icon
                                name="arrow-left-circle"
                                color={AppColors.backGround2}
                                size={35}
                                style={{
                                    marginTop: 15,
                                    alignSelf: "center"
                                }}
                            />
                        </TouchableOpacity>
                        <View style={{ flex: 0.7, justifyContent: "center", }}>
                            <Text style={styles.title}>Manage Cities</Text>
                        </View>

                        <View style={{ flex: 0.15 }}>
                        </View>
                    </View>
                    <View style={{ flex: 0.13, marginTop: 15, flexDirection: "row", paddingLeft: 10, marginHorizontal: 15, borderRadius: 10, backgroundColor: AppColors.backGround1, }}>
                        <View style={{ flex: 0.8, justifyContent: "center" }}>
                            <TextInput
                                placeholder='Enter City Name'
                                placeholderTextColor={AppColors.white}
                                style={{ textAlign: 'left' }}
                            />
                        </View>
                        <View style={{ flex: 0.2, justifyContent: "center", alignItems: "center" }}>
                            <FeatherIcon
                                name="search"
                                color={AppColors.Orange}
                                size={25}
                                style={{
                                    marginTop: 15,
                                    alignSelf: "center"
                                }}
                            />
                        </View>

                    </View>
                    <View style={{ flex: 0.8, }}>
                    
                        <FlatList
                            data={Data}
                            renderItem={item => renderList(item.item,)}
                            listKey={(item, index) => 'b' + index + item.id.toString()}
                            showsHorizontalScrollIndicator={false}
                            showsVerticalScrollIndicator={false}
                            contentContainerStyle={{ justifyContent: 'center', }}
                        />
                      
                    </View>
                </View>



            </LinearGradient>
        </>
    )
}
export default ManageCities