import React, {useEffect} from 'react';
import {
  AppRegistry,
  StyleSheet,
  Text,
  View,
  StatusBar,
  FlatList,
  TouchableOpacity
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Header from "../../Component/Header";
import FeatherIcon from 'react-native-vector-icons/Feather';
import { AppColors, AppConstants } from "../../Theme";
import styles from "./style";
import {cityDataAction} from "../../Redux/Actions/CityDataActions";
import { connect, useSelector, useDispatch } from 'react-redux';
import { Loader } from "../../Component/Loader";
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
const Home = (props) => {

  const dispatch = useDispatch()
  const cityData = useSelector((state) => state.cityDataReducer)
  const allWeatherData = useSelector((state) => state.allWeatherDataReducer)

  allWeatherDataReducer

  useEffect(() => {
    console.log('useeffect call');
   dispatch(cityDataAction("Mohali", AppConstants.constants.APIKEY))
  },[])

  useEffect(() => {
    console.log('cityDataAction useEffect--->', cityData);
  },[cityData])

  useEffect(() => {
    // console.log('allWeatherData useEffect--->', allWeatherData);
  },[])

  const Data = [
    {
      time: 'Now',
      Icon1: 'sun',
      tempr: '32°',
      icon2: 'play-circle-outline',
      speed: '2km/h',
      id: "1"
    },
    {
      time: 'Now',
      Icon1: 'sun',
      tempr: '32°',
      icon2: 'play-circle-outline',
      speed: '2km/h',
      id: "2"
    },
    {
      time: 'Now',
      Icon1: 'sun',
      tempr: '32°',
      icon2: 'play-circle-outline',
      speed: '2km/h',
      id: "3"
    },
    {
      time: 'Now',
      Icon1: 'sun',
      tempr: '32°',
      icon2: 'play-circle-outline',
      speed: '2km/h',
      id: "4"
    },
    {
      time: 'Now',
      Icon1: 'sun',
      tempr: '32°',
      icon2: 'play-circle-outline',
      speed: '2km/h',
      id: "5"
    },
    {
      time: 'Now',
      Icon1: 'sun',
      tempr: '32°',
      icon2: 'play-circle-outline',
      speed: '2km/h',
      id: "6"
    },
    {
      time: 'Now',
      Icon1: 'sun',
      tempr: '32°',
      icon2: 'play-circle-outline',
      speed: '2km/h',
      id: "7"
    },
  ]

  const renderList = () => {
    return (
      <View style={{ flex: 1, marginHorizontal: 5.5, justifyContent: "center" }}>
        <Text style={styles.listText}>Now</Text>
        <FeatherIcon
          name="sun"
          color={AppColors.white}
          size={25}
          style={{
            alignSelf: "center",
            marginBottom: 10
          }}
        />
        <Text style={styles.listText}>32°</Text>
        <Icon
              name="speedometer-medium"
              color={AppColors.white}
              size={25}
              style={{
                alignSelf: "center",
                marginBottom: 10
              }}
            />
        <Text style={styles.listText}>2 km/h</Text>
      </View>
    )
  }

  return (
    // <View style={styles.container}>
    <>
      <StatusBar barStyle="dark-content" hidden={false} backgroundColor="#043B5D" translucent={true} />
      <LinearGradient 
      colors={[AppColors.backGround1, AppColors.backGround2]} 
      style={styles.linearGradient}
      start={{x:0, y:0}} end = {{x : 1 , y : 1}}
      >
        <Header
          title={cityData ? cityData.result != null ? cityData.result.name : "" : ""}
          leftIcon={"plus-circle"}
          rightIcon={"plus-circle"}
          leftClick = {() => props.navigation.navigate('ManagesCities')}
          rightClick = {() => props.navigation.toggleDrawer()}

        />
        <View style={styles.container}>
          <View style={{ flex: 0.15, }}>
            <FeatherIcon
              name="sun"
              color={AppColors.white}
              size={50}
              style={{
                marginTop: 15,
                alignSelf: "center"
              }}
            />
            <Text style={{ textAlign: "center", fontSize: 20, color: AppColors.white }}>Sunny</Text>
          </View>

          <View style={{ flex: 0.1, }}>
            <Text style={styles.tempText}>32 <Text style={{ textAlign: "auto", fontSize: 20, color: AppColors.white }}>°C</Text></Text>
            <Text style={{ textAlign: 'center', fontSize: 15, color: AppColors.white }}>Feels like 36°</Text>
          </View>

          <View style={{ flex: 0.25, paddingHorizontal: 10, justifyContent: "center", alignItems: "center" }}>
            <FlatList
              data={Data}
              renderItem={item => renderList(item.item,)}
              listKey={(item, index) => 'b' + index + item.id.toString()}
              showsHorizontalScrollIndicator={false}
              showsVerticalScrollIndicator={false}
              contentContainerStyle={{ justifyContent: 'center',  }}
              horizontal={true}
            />
          </View>

          <View style={styles.weatherView}>
            <View style={styles.tommorowWeatherView}>
              <View style={styles.innerView}>
                <View style={styles.iconView}>
                  <FeatherIcon
                    name="sun"
                    color={AppColors.white}
                    size={25}
                  />
                </View>
                <View style={styles.innerTextView}>
                  <Text style={{ color: AppColors.white, fontSize: 20, }}>Tomorrow - Clear</Text>
                </View>
                <View style={styles.tempInnerView}>
                  <Text style={{ color: AppColors.white, fontSize: 20, }}>35° / 26°</Text>
                </View>
              </View>

              <View style={styles.innerView}>
                <View style={styles.iconView}>
                  <FeatherIcon
                    name="sun"
                    color={AppColors.white}
                    size={25}
                  />
                </View>
                <View style={styles.innerTextView}>
                  <Text style={styles.dayText}>Wed - Clear</Text>
                </View>
                <View style={styles.tempInnerView}>
                  <Text style={{ color: AppColors.white, fontSize: 20, }}>35° / 26°</Text>
                </View>
              </View>
            </View>

            <View style={styles.windHumidity}>
              <View style={{ flex: 0.5, }}>
                <View style={{ flex: 0.5, justifyContent: "center",paddingLeft:15 }}>
                  <Text style={[styles.listText, { marginBottom: 0, textAlign:"left" }]}>Wind</Text>
                  <Text style={{ color: AppColors.white, fontSize: 20, textAlign: "left" }}>2.1 km/h</Text>
                </View>
                <View style={{ flex: 0.5, justifyContent: "center", paddingLeft:15 }}>
                  <Text style={[styles.listText, { marginBottom: 0, textAlign:"left" }]}>Wind</Text>
                  <Text style={{ color: AppColors.white, fontSize: 20, textAlign: "left" }}>2.1 km/h</Text>
                </View>
              </View>

              <View style={{ flex: 0.5,  }}>
                <View style={{ flex: 0.5, justifyContent: "center",paddingRight:15 }}>
                  <Text style={[styles.listText, { marginBottom: 0, textAlign:"right" }]}>Wind</Text>
                  <Text style={{ color: AppColors.white, fontSize: 20, textAlign: "right" }}>2.1 km/h</Text>
                </View>
                <View style={{ flex: 0.5, justifyContent: "center", paddingRight:15 }}>
                  <Text style={[styles.listText, { marginBottom: 0, textAlign:"right" }]}>Wind</Text>
                  <Text style={{ color: AppColors.white, fontSize: 20, textAlign: "right" }}>2.1 km/h</Text>
                </View>
              </View>

            </View>

          </View>

          <View style={{ flex: 0.15, justifyContent: "center", paddingHorizontal: 15 }}>

            <TouchableOpacity 
             onPress={() => props.navigation.navigate('CityForecast')}
            style={{ height: 50, backgroundColor: AppColors.Orange, borderRadius: 25, justifyContent: "center", alignItems: "center" }}>
              <Text style={{ color: AppColors.white, fontSize: 15, fontWeight: "bold" }}>5-day forecast</Text>
            </TouchableOpacity>
          </View>


        </View>
        <Loader loading={cityData.isLoading}/>
      </LinearGradient>
    </>
  );
};

export default Home