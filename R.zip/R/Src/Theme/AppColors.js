const colors = {
   backGround1:"#043B5D",
   backGround2:"#6B9FB7",
   white:"#ffffff",
   Orange:"#FF9300",
   lightBox:"043B5D40",
   red:"red"
}

export default colors