import { combineReducers } from 'redux';
import { cityDataReducer,allWeatherDataReducer } from "./CityDataReducer";

const appReducer = combineReducers({
    cityDataReducer,
    allWeatherDataReducer
})

const rootReducer = (state, action) => {
    if(action.type === 'API_LOGOUT_SUCCESS'){

    }
    return appReducer(state, action)
}

export default rootReducer