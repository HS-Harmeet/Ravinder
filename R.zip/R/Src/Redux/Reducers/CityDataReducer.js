import { apiConstants as types } from "../ActionTypes";

const initialState = {
    isLoading: false,
    result: null,
    errorState: null,
    isExpired: null,
    status: 0,
    fcmToke: "",
    
}

// cityDataReducer 
const cityDataReducer = (state = initialState, action) => {
    console.log('city data REDUCER=---->', action);
    switch (action.type) {

        case types.CITY_WEATHER_LOAD:
            return { ...state, isLoading: true };

        case types.CITY_WEATHER_SUCCESS:
            return {
                ...state,
                isLoading: false,
                result: action.result
            };
        case types.CITY_WEATHER_FAIL:
            return { ...state, isLoading: false, };

        case types.CITY_WEATHER_ERROR:
            return { ...state, isLoading: false };

        default:
            return state;
    }
}

// cityDataReducer 
const allWeatherDataReducer = (state = initialState, action) => {
 
    switch (action.type) {

        case types.API_ALL_WEATHER_DATA_LOAD:
            return { ...state, isLoading: true };

        case types.API_ALL_WEATHER_DATA_SUCCESS:
            console.log('allWeatherDataReducer data REDUCER=---->', action.result);
            return {
                ...state,
                isLoading: false,
                result: action.result
            };
        case types.API_ALL_WEATHER_DATA_FAIL:
            return { ...state, isLoading: false, };

        case types.API_ALL_WEATHER_DATA_ERROR:
            return { ...state, isLoading: false };

        default:
            return state;
    }
}

module.exports = {
    cityDataReducer,
    allWeatherDataReducer
}
