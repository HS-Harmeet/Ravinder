import { takeLatest, call, put } from "redux-saga/effects";
import axios from "../Axios";
import { apiConstants as types } from "../ActionTypes";

export function* authenticationFailedSaga(result) {

    yield put({
        type: types.CITY_WEATHER_FAIL,
    })
    setTimeout(() => {
                 
    }, 500)

}

// Generator to run when Authentication Error occured in response
function* authenticationErrorSaga(result) {
    console.log('errrr', result);
    yield put({
        type: types.CITY_WEATHER_ERROR,
    })

}

export function* cityDataSaga(action) {
    const { payload, navigation } = action;
    console.log('city data saga call', action);
    try {
        const result = yield call(axios.cityData, action.cityName, action.apiKey)
        console.log('cityData--> result', result);
        if (result.status === 1) {
            if(result.result.status == 200){
                yield put({
                    type: types.CITY_WEATHER_SUCCESS,
                    result: result.result.data,
                })
                console.log('cityData Result', result.result.data);
                const allResult = yield call(axios.allWeatherData, result.result.data.coord.lat,result.result.data.coord.lon,'hourly', action.apiKey)
                console.log('allResult -->',allResult);
                if(allResult.status == 1){
                    if(allResult.result.status == 200){
                        yield put({
                            type: types.API_ALL_WEATHER_DATA_SUCCESS,
                            result: allResult.result.data,
                        })
                    }
                }
            }
            // alert(result.result.data[0].message)
            // AsyncStorage.setItem('detail', payload)
                  
        }
        else {
            yield call(authenticationFailedSaga, result)
        }
    }
    catch (error) {
        yield call(authenticationErrorSaga, error)
    }
}