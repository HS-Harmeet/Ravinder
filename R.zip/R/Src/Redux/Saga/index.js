import { takeEvery, takeLatest } from 'redux-saga/effects';
import { apiConstants as types } from "../ActionTypes";
import { cityDataSaga } from "./cityDataSaga";

export default function* rootSaga(){    
    yield takeEvery(types.CITY_WEATHER_LOAD ,cityDataSaga)
}